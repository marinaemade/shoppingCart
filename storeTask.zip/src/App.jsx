import { useState } from "react";
import Nav from "./components/Nav";
import Section from "./components/Section";

const App = () => {

  let [products] = useState(
    [
      { id: 0, name: "pepsi", price: 10, count: 1 },
      { id: 1, name: "kranchy", price: 20, count: 2 },
      { id: 2, name: "kola", price: 30, count: 3 },
      { id: 3, name: "chepsy", price: 40, count: 4 },
    ]
  );

  return (
    <>
      <Nav />
      <Section products={products}/>
    </>
  )
}

export default App