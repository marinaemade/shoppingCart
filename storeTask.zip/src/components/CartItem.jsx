const CartItem = ({product:{name,price,count}}) => {
  return (
    <div className="flex flex-col sm:flex-row flex-wrap items-center container mx-auto gap-4 sm:justify-evenly bg-slate-200/70 dark:bg-slate-800/70 rounded p-4">

      <div className="flex gap-4">
        <h1>{name}</h1> 
        <h1>${price}</h1> 
        <h1> count: {count}</h1> 
        
      </div>

      <div className="flex gap-4">
        <button className="btn btn-success">+</button>
        <button className="btn btn-error">-</button>
        <button className="btn btn-warning">delete</button>
      </div>

      <div>
        Total: 200$
      </div>

    </div>
  )
}

export default CartItem