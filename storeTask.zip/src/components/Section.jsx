import CartItem from "./CartItem"

const Section = ({products}) => {
  return (
    <div className="h-screen text-center space-y-4">
      <h1 className="text-2xl fw-bold pb-3">Your Cart </h1>
      {products.map((product)=>(
        <CartItem product={product} key={product.id}/>
      ))}

      <h1 className="text-2xl fw-bold pt-3">Total: $500</h1>
    </div>
    
  )
}

export default Section